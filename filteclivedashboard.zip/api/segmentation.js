'use strict';

var erpGet = require('../lib/erpnext').erpGet;

function daysBetween(dateStr, now) {
  var d = new Date(dateStr);
  if (isNaN(d.getTime())) return null;
  var diffMs = now.getTime() - d.getTime();
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * GET /api/segmentation
 *
 * Segment A/B via a dynamic Pareto cutoff (~80% cumulative revenue),
 * recency buckets from each customer's most recent posting_date to the
 * server's current date, and win-back candidates (recency > 90 days,
 * total sales >= Rp 20,000,000).
 */
module.exports = async function handler(req, res) {
  try {
    var invoices = await erpGet('Sales Invoice', {
      fields: ['name', 'customer_name', 'base_grand_total', 'posting_date'],
      filters: [['docstatus', '=', 1]],
    });

    var byCustomer = new Map();
    for (var i = 0; i < invoices.length; i++) {
      var inv = invoices[i];
      var key = inv.customer_name || 'Unknown Customer';
      if (!byCustomer.has(key)) {
        byCustomer.set(key, { sales: 0, invoices: 0, lastPurchase: null });
      }
      var c = byCustomer.get(key);
      c.sales += Number(inv.base_grand_total) || 0;
      c.invoices += 1;
      var d = inv.posting_date;
      if (d && (!c.lastPurchase || d > c.lastPurchase)) c.lastPurchase = d;
    }

    var allCustomers = [];
    byCustomer.forEach(function (c, customer_name) {
      allCustomers.push({
        customer_name: customer_name,
        sales: c.sales,
        invoices: c.invoices,
        lastPurchaseDate: c.lastPurchase,
      });
    });

    allCustomers.sort(function (a, b) {
      return b.sales - a.sales;
    });

    var totalSales = allCustomers.reduce(function (sum, c) {
      return sum + c.sales;
    }, 0);

    var running = 0;
    var cutoffReached = false;
    var segmentA = [];
    var segmentATotal = 0;
    var segmentBTotal = 0;

    for (var j = 0; j < allCustomers.length; j++) {
      var cust = allCustomers[j];
      running += cust.sales;
      var cumulativePct = totalSales > 0 ? (running / totalSales) * 100 : 0;
      if (!cutoffReached) {
        segmentA.push({
          customer_name: cust.customer_name,
          sales: cust.sales,
          invoices: cust.invoices,
          cumulativePct: cumulativePct,
        });
        segmentATotal += cust.sales;
        if (cumulativePct >= 80) cutoffReached = true;
      } else {
        segmentBTotal += cust.sales;
      }
    }

    var now = new Date();
    var buckets = {
      '0-30 days': { customerCount: 0, revenueTotal: 0 },
      '31-60 days': { customerCount: 0, revenueTotal: 0 },
      '61-90 days': { customerCount: 0, revenueTotal: 0 },
      '90+ days': { customerCount: 0, revenueTotal: 0 },
    };

    var winBackCandidates = [];

    for (var k = 0; k < allCustomers.length; k++) {
      var c2 = allCustomers[k];
      var days = c2.lastPurchaseDate ? daysBetween(c2.lastPurchaseDate, now) : null;
      if (days === null) continue;

      var label;
      if (days <= 30) label = '0-30 days';
      else if (days <= 60) label = '31-60 days';
      else if (days <= 90) label = '61-90 days';
      else label = '90+ days';

      buckets[label].customerCount += 1;
      buckets[label].revenueTotal += c2.sales;

      if (days > 90 && c2.sales >= 20000000) {
        winBackCandidates.push({
          customer_name: c2.customer_name,
          sales: c2.sales,
          lastPurchaseDate: c2.lastPurchaseDate,
          daysSince: days,
        });
      }
    }

    winBackCandidates.sort(function (a, b) {
      return b.sales - a.sales;
    });

    var recencyBuckets = Object.keys(buckets).map(function (label) {
      return {
        label: label,
        customerCount: buckets[label].customerCount,
        revenueTotal: buckets[label].revenueTotal,
      };
    });

    res.status(200).json({
      segmentA: segmentA,
      segmentATotal: segmentATotal,
      segmentBTotal: segmentBTotal,
      recencyBuckets: recencyBuckets,
      winBackCandidates: winBackCandidates,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
