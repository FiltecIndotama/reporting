# Filtec Reporting

This repo is a plain static-HTML + Vercel serverless-functions project (no frontend
framework, no build step). Vercel auto-detects it as a static + `/api` project.

- `filtec-sales-dashboard.html` — the original hardcoded-data snapshot dashboard (root level).
  Left untouched.
- `Filtec/filtec-sales-dashboard.html` — the **live** dashboard. Same visual design (dark
  theme, 7-tab bar, chart-card/track/fill bar charts, tables, EN/ZH/ID language toggle), but
  fetches real data client-side from the `/api/*` endpoints below instead of using hardcoded
  numbers.
- `lib/erpnext.js` — shared ERPNext REST helper (`erpGet(doctype, { fields, filters })`) used
  by every API route.
- `api/brand.js`, `api/key-accounts.js`, `api/gp.js`, `api/retention.js`,
  `api/segmentation.js`, `api/expenses.js`, `api/net-profit.js` — one serverless function per
  dashboard tab. Each returns `{ error: message }` with HTTP 500 on failure instead of
  crashing, so issues are debuggable via Vercel function logs.

## Required environment variables

The live dashboard talks to ERPNext through these three environment variables. **They must
be set in the Vercel project's dashboard under Settings → Environment Variables — never
hardcoded or committed to this repo.**

| Variable | Description |
| --- | --- |
| `ERPNEXT_URL` | Base URL of the ERPNext instance, e.g. `https://crm.filtec.co.id` |
| `ERPNEXT_API_KEY` | ERPNext REST API key |
| `ERPNEXT_API_SECRET` | ERPNext REST API secret |

`lib/erpnext.js` reads these via `process.env` at request time and sends
`Authorization: token {ERPNEXT_API_KEY}:{ERPNEXT_API_SECRET}` on every request. If any of the
three are missing, every `/api/*` route returns a clear `{ error: ... }` message rather than
throwing an unhandled exception.

## Local notes

- No dependencies — everything runs on Node 18+'s built-in global `fetch` (Vercel's Node
  runtime supports this natively).
- No `vercel.json` — the project is zero-config (static files + `/api` functions).
- This environment could not reach `https://crm.filtec.co.id` to test the API calls live
  (network-sandboxed dev environment); the code was written defensively against the
  documented ERPNext REST schema and should be verified against real data once deployed.
