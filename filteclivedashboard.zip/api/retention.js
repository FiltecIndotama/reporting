'use strict';

var erpGet = require('../lib/erpnext').erpGet;

/**
 * GET /api/retention
 *
 * Buckets customers by how many submitted Sales Invoices they have
 * (1 / 2 / 3+), and returns the detail list of repeat customers (2+).
 */
module.exports = async function handler(req, res) {
  try {
    var invoices = await erpGet('Sales Invoice', {
      fields: ['name', 'customer_name', 'base_grand_total', 'posting_date'],
      filters: [['docstatus', '=', 1]],
    });

    var byCustomer = new Map();
    for (var i = 0; i < invoices.length; i++) {
      var inv = invoices[i];
      var key = inv.customer_name || 'Unknown Customer';
      if (!byCustomer.has(key)) {
        byCustomer.set(key, { invoices: 0, sales: 0, first: null, last: null });
      }
      var c = byCustomer.get(key);
      c.invoices += 1;
      c.sales += Number(inv.base_grand_total) || 0;
      var d = inv.posting_date;
      if (d) {
        if (!c.first || d < c.first) c.first = d;
        if (!c.last || d > c.last) c.last = d;
      }
    }

    var bucket1 = 0;
    var bucket2 = 0;
    var bucket3plus = 0;
    var repeatCustomers = [];

    byCustomer.forEach(function (c, customer_name) {
      if (c.invoices === 1) bucket1++;
      else if (c.invoices === 2) bucket2++;
      else bucket3plus++;

      if (c.invoices >= 2) {
        repeatCustomers.push({
          customer_name: customer_name,
          invoices: c.invoices,
          sales: c.sales,
          firstInvoiceDate: c.first,
          lastInvoiceDate: c.last,
        });
      }
    });

    repeatCustomers.sort(function (a, b) {
      return b.sales - a.sales;
    });

    res.status(200).json({
      frequencyBuckets: [
        { label: '1 invoice', customerCount: bucket1 },
        { label: '2 invoices', customerCount: bucket2 },
        { label: '3+ invoices', customerCount: bucket3plus },
      ],
      repeatCustomers: repeatCustomers,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
