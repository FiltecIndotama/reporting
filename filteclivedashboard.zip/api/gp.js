'use strict';

var erpGet = require('../lib/erpnext').erpGet;

function monthKey(dateStr) {
  if (!dateStr) return 'Unknown';
  return String(dateStr).slice(0, 7); // YYYY-MM
}

/**
 * GET /api/gp
 *
 * Joins Sales Invoice Item rows to their parent Sales Invoice (for
 * posting_date / company), then computes gross profit by month and by item.
 * Cost = incoming_rate * qty. Rows with incoming_rate === 0 have no cost
 * data and are reported separately as "coverage" so GP% isn't misleading.
 */
module.exports = async function handler(req, res) {
  try {
    var results = await Promise.all([
      erpGet('Sales Invoice', {
        fields: ['name', 'posting_date', 'company'],
        filters: [['docstatus', '=', 1]],
      }),
      erpGet('Sales Invoice Item', {
        fields: ['parent', 'item_code', 'item_name', 'base_net_amount', 'incoming_rate', 'qty'],
        filters: [['docstatus', '=', 1]],
      }),
    ]);
    var invoices = results[0];
    var items = results[1];

    var invoiceMap = new Map();
    for (var i = 0; i < invoices.length; i++) {
      invoiceMap.set(invoices[i].name, {
        posting_date: invoices[i].posting_date,
        company: invoices[i].company,
      });
    }

    var byMonth = new Map(); // month -> { revenue, cost }
    var withCost = 0;
    var withoutCost = 0;
    var byItem = new Map(); // item_code -> { item_name, revenue, cost }

    for (var j = 0; j < items.length; j++) {
      var row = items[j];
      var inv = invoiceMap.get(row.parent);
      var revenue = Number(row.base_net_amount) || 0;
      var incomingRate = Number(row.incoming_rate) || 0;
      var qty = Number(row.qty) || 0;
      var cost = incomingRate * qty;

      var month = inv ? monthKey(inv.posting_date) : 'Unknown';
      if (!byMonth.has(month)) byMonth.set(month, { revenue: 0, cost: 0 });
      var m = byMonth.get(month);
      m.revenue += revenue;
      m.cost += cost;

      if (incomingRate > 0) {
        withCost += revenue;
        var itemKey = row.item_code || 'Unknown Item';
        if (!byItem.has(itemKey)) {
          byItem.set(itemKey, { item_name: row.item_name || itemKey, revenue: 0, cost: 0 });
        }
        var it = byItem.get(itemKey);
        it.revenue += revenue;
        it.cost += cost;
      } else {
        withoutCost += revenue;
      }
    }

    var byMonthList = [];
    byMonth.forEach(function (v, month) {
      byMonthList.push({
        month: month,
        revenue: v.revenue,
        cost: v.cost,
        gpPct: v.revenue !== 0 ? ((v.revenue - v.cost) / v.revenue) * 100 : 0,
      });
    });
    byMonthList.sort(function (a, b) {
      return a.month < b.month ? -1 : a.month > b.month ? 1 : 0;
    });

    var byItemList = [];
    byItem.forEach(function (v, item_code) {
      byItemList.push({
        item_code: item_code,
        item_name: v.item_name,
        revenue: v.revenue,
        cost: v.cost,
        gp: v.revenue - v.cost,
      });
    });
    byItemList.sort(function (a, b) {
      return b.revenue - a.revenue;
    });

    var top15 = byItemList.slice(0, 15);
    var remainingRevenue = byItemList.slice(15).reduce(function (sum, it2) {
      return sum + it2.revenue;
    }, 0);

    res.status(200).json({
      byMonth: byMonthList,
      coverage: { withCost: withCost, withoutCost: withoutCost },
      byItem: top15,
      remainingRevenue: remainingRevenue,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
