'use strict';

var erpGet = require('../lib/erpnext').erpGet;

function deriveStatus(statuses) {
  if (statuses.length === 1) return statuses[0] || 'Unknown';
  var hasOverdue = statuses.some(function (s) {
    return typeof s === 'string' && s.indexOf('Overdue') !== -1;
  });
  if (hasOverdue) return 'Has Overdue';
  var allPaid = statuses.every(function (s) {
    return s === 'Paid';
  });
  if (allPaid) return 'Paid';
  return statuses[statuses.length - 1] || 'Mixed';
}

/**
 * GET /api/key-accounts
 *
 * Groups submitted Sales Invoices by customer, ranks by revenue, and
 * computes a dynamic Pareto cutoff (~80% of cumulative revenue) to identify
 * "key accounts" rather than hardcoding a fixed count.
 */
module.exports = async function handler(req, res) {
  try {
    var invoices = await erpGet('Sales Invoice', {
      fields: ['name', 'customer', 'customer_name', 'base_grand_total', 'outstanding_amount', 'status', 'posting_date'],
      filters: [['docstatus', '=', 1]],
    });

    var byCustomer = new Map();
    for (var i = 0; i < invoices.length; i++) {
      var inv = invoices[i];
      var key = inv.customer_name || inv.customer || 'Unknown Customer';
      if (!byCustomer.has(key)) {
        byCustomer.set(key, { sales: 0, invoices: 0, statuses: [], overdueOutstanding: 0 });
      }
      var c = byCustomer.get(key);
      c.sales += Number(inv.base_grand_total) || 0;
      c.invoices += 1;
      var status = inv.status || '';
      c.statuses.push(status);
      if (status.indexOf('Overdue') !== -1) {
        c.overdueOutstanding += Number(inv.outstanding_amount) || 0;
      }
    }

    var allCustomers = [];
    byCustomer.forEach(function (c, customer_name) {
      allCustomers.push({
        customer_name: customer_name,
        sales: c.sales,
        invoices: c.invoices,
        status: deriveStatus(c.statuses),
        overdueOutstanding: c.overdueOutstanding,
      });
    });

    allCustomers.sort(function (a, b) {
      return b.sales - a.sales;
    });

    var totalSales = allCustomers.reduce(function (sum, c) {
      return sum + c.sales;
    }, 0);

    var running = 0;
    var cutoffReached = false;
    var keyAccountRevenue = 0;
    var keyAccountOverdue = 0;

    for (var j = 0; j < allCustomers.length; j++) {
      var cust = allCustomers[j];
      running += cust.sales;
      cust.cumulativePct = totalSales > 0 ? (running / totalSales) * 100 : 0;
      if (!cutoffReached) {
        cust.isKeyAccount = true;
        keyAccountRevenue += cust.sales;
        keyAccountOverdue += cust.overdueOutstanding;
        if (cust.cumulativePct >= 80) cutoffReached = true;
      } else {
        cust.isKeyAccount = false;
      }
    }

    var repeatCustomerCount = allCustomers.filter(function (c) {
      return c.invoices >= 2;
    }).length;

    var topCustomers = allCustomers.slice(0, 10).map(function (c) {
      return {
        customer_name: c.customer_name,
        sales: c.sales,
        invoices: c.invoices,
        cumulativePct: c.cumulativePct,
        status: c.status,
        isKeyAccount: c.isKeyAccount,
      };
    });

    res.status(200).json({
      topCustomers: topCustomers,
      totalSales: totalSales,
      keyAccountRevenue: keyAccountRevenue,
      keyAccountOverdue: keyAccountOverdue,
      repeatCustomerCount: repeatCustomerCount,
      uniqueCustomerCount: allCustomers.length,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
