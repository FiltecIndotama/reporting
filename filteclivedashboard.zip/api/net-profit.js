'use strict';

var erpGet = require('../lib/erpnext').erpGet;

function isoDate(d) {
  return d.toISOString().slice(0, 10);
}

/**
 * GET /api/net-profit
 *
 * True bottom-line P&L for the current year to date (Jan 1 -> today,
 * computed server-side). Unlike api/expenses.js (which excludes the
 * 5110.020 Stock Adjustment account purely for chart clarity), this tab
 * includes ALL Expense accounts because it needs to report the actual
 * Net Profit line.
 */
module.exports = async function handler(req, res) {
  try {
    var now = new Date();
    var periodStart = now.getFullYear() + '-01-01';
    var periodEnd = isoDate(now);

    var accounts = await erpGet('Account', {
      fields: ['name', 'root_type', 'company'],
    });

    var incomeAccounts = new Set();
    var expenseAccounts = new Set();
    var companiesSet = new Set();

    for (var i = 0; i < accounts.length; i++) {
      var a = accounts[i];
      if (a.root_type === 'Income') incomeAccounts.add(a.name);
      if (a.root_type === 'Expense') expenseAccounts.add(a.name);
      if (a.company) companiesSet.add(a.company);
    }

    var glEntries = await erpGet('GL Entry', {
      fields: ['account', 'debit', 'credit', 'company', 'posting_date'],
      filters: [
        ['is_cancelled', '=', 0],
        ['posting_date', '>=', periodStart],
        ['posting_date', '<=', periodEnd],
      ],
    });

    var byCompany = new Map(); // company -> { revenue, totalExpense }

    for (var j = 0; j < glEntries.length; j++) {
      var g = glEntries[j];
      var company = g.company || 'Unknown Company';
      companiesSet.add(company);
      if (!byCompany.has(company)) byCompany.set(company, { revenue: 0, totalExpense: 0 });
      var c = byCompany.get(company);
      var debit = Number(g.debit) || 0;
      var credit = Number(g.credit) || 0;

      if (incomeAccounts.has(g.account)) {
        c.revenue += credit - debit;
      } else if (expenseAccounts.has(g.account)) {
        c.totalExpense += debit - credit;
      }
    }

    var byCompanyList = [];
    var combinedRevenue = 0;
    var combinedExpense = 0;

    companiesSet.forEach(function (company) {
      var c = byCompany.get(company) || { revenue: 0, totalExpense: 0 };
      var netProfit = c.revenue - c.totalExpense;
      var marginPct = c.revenue !== 0 ? (netProfit / c.revenue) * 100 : 0;
      byCompanyList.push({
        company: company,
        revenue: c.revenue,
        totalExpense: c.totalExpense,
        netProfit: netProfit,
        marginPct: marginPct,
      });
      combinedRevenue += c.revenue;
      combinedExpense += c.totalExpense;
    });

    byCompanyList.sort(function (a, b) {
      return b.revenue - a.revenue;
    });

    var combinedNetProfit = combinedRevenue - combinedExpense;
    var combinedMarginPct = combinedRevenue !== 0 ? (combinedNetProfit / combinedRevenue) * 100 : 0;

    res.status(200).json({
      byCompany: byCompanyList,
      combined: {
        revenue: combinedRevenue,
        totalExpense: combinedExpense,
        netProfit: combinedNetProfit,
        marginPct: combinedMarginPct,
      },
      periodStart: periodStart,
      periodEnd: periodEnd,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
