'use strict';

var erpGet = require('../lib/erpnext').erpGet;

var STOCK_ADJ_MARKER = '5110.020';

function monthKey(dateStr) {
  if (!dateStr) return 'Unknown';
  return String(dateStr).slice(0, 7); // YYYY-MM
}

/**
 * GET /api/expenses
 *
 * Expense accounts (root_type = Expense), EXCLUDING the 5110.020 "Stock
 * Adjustment" account (identified by its `name` containing "5110.020"),
 * grouped by month and by account+company from GL Entry rows.
 *
 * Primary approach: filter GL Entry server-side with an "account in [...]"
 * filter. If the ERPNext instance rejects that (e.g. filter list too large),
 * fall back to fetching all non-cancelled GL Entry rows plus a full
 * Account name -> root_type map, and filter client-side instead.
 */
module.exports = async function handler(req, res) {
  try {
    var expenseAccounts = await erpGet('Account', {
      fields: ['name', 'account_name', 'company'],
      filters: [['root_type', '=', 'Expense']],
    });

    var allowedAccounts = expenseAccounts.filter(function (a) {
      return !(a.name && a.name.indexOf(STOCK_ADJ_MARKER) !== -1);
    });
    var allowedNames = allowedAccounts.map(function (a) {
      return a.name;
    });

    var glEntries;
    try {
      if (allowedNames.length === 0) {
        glEntries = [];
      } else {
        glEntries = await erpGet('GL Entry', {
          fields: ['account', 'debit', 'credit', 'posting_date', 'company'],
          filters: [
            ['is_cancelled', '=', 0],
            ['account', 'in', allowedNames],
          ],
        });
      }
    } catch (inFilterErr) {
      // Fallback: some ERPNext instances reject a very large "in" filter
      // list. Re-fetch all non-cancelled GL Entry rows and filter
      // client-side using a full Account name -> root_type map.
      var allAccounts = await erpGet('Account', {
        fields: ['name', 'account_name', 'root_type', 'company'],
      });
      var rootTypeMap = new Map();
      allAccounts.forEach(function (a) {
        rootTypeMap.set(a.name, a.root_type);
      });

      var allGlEntries = await erpGet('GL Entry', {
        fields: ['account', 'debit', 'credit', 'posting_date', 'company'],
        filters: [['is_cancelled', '=', 0]],
      });

      glEntries = allGlEntries.filter(function (g) {
        if (!g.account) return false;
        if (g.account.indexOf(STOCK_ADJ_MARKER) !== -1) return false;
        return rootTypeMap.get(g.account) === 'Expense';
      });
    }

    var byMonth = new Map();
    var byAccount = new Map(); // "account||company" -> amount

    for (var i = 0; i < glEntries.length; i++) {
      var g = glEntries[i];
      // Defensive re-check even on the primary (server-filtered) path.
      if (g.account && g.account.indexOf(STOCK_ADJ_MARKER) !== -1) continue;

      var amount = (Number(g.debit) || 0) - (Number(g.credit) || 0);
      var month = monthKey(g.posting_date);
      byMonth.set(month, (byMonth.get(month) || 0) + amount);

      var acctKey = (g.account || 'Unknown Account') + '||' + (g.company || '');
      byAccount.set(acctKey, (byAccount.get(acctKey) || 0) + amount);
    }

    var byMonthList = [];
    byMonth.forEach(function (amount, month) {
      byMonthList.push({ month: month, amount: amount });
    });
    byMonthList.sort(function (a, b) {
      return a.month < b.month ? -1 : a.month > b.month ? 1 : 0;
    });

    var byAccountList = [];
    byAccount.forEach(function (amount, key) {
      var parts = key.split('||');
      byAccountList.push({ account: parts[0], company: parts[1], amount: amount });
    });
    byAccountList.sort(function (a, b) {
      return Math.abs(b.amount) - Math.abs(a.amount);
    });
    byAccountList = byAccountList.slice(0, 15);

    res.status(200).json({ byMonth: byMonthList, byAccount: byAccountList });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
