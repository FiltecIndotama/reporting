'use strict';

var erpGet = require('../lib/erpnext').erpGet;

/**
 * GET /api/brand
 *
 * Sales grouped by the brand tagged on each Sales Invoice Item, across all
 * submitted (docstatus = 1) invoices, both companies combined.
 */
module.exports = async function handler(req, res) {
  try {
    var items = await erpGet('Sales Invoice Item', {
      fields: ['item_code', 'brand', 'base_net_amount', 'parent'],
      filters: [['docstatus', '=', 1]],
    });

    var groups = new Map(); // brand -> { total, invoices: Set }
    var grandInvoices = new Set();

    for (var i = 0; i < items.length; i++) {
      var row = items[i];
      var brandRaw = row.brand;
      var brand = brandRaw && String(brandRaw).trim() !== '' ? String(brandRaw).trim() : 'Unbranded';
      var amount = Number(row.base_net_amount) || 0;

      if (!groups.has(brand)) {
        groups.set(brand, { total: 0, invoices: new Set() });
      }
      var g = groups.get(brand);
      g.total += amount;
      if (row.parent) {
        g.invoices.add(row.parent);
        grandInvoices.add(row.parent);
      }
    }

    var groupList = [];
    var grandTotal = 0;
    groups.forEach(function (g, brand) {
      groupList.push({ brand: brand, total: g.total, invoiceCount: g.invoices.size });
      grandTotal += g.total;
    });
    groupList.sort(function (a, b) {
      return b.total - a.total;
    });

    res.status(200).json({
      groups: groupList,
      grandTotal: grandTotal,
      grandInvoiceCount: grandInvoices.size,
    });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
};
